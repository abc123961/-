// app.js
App({
  globalData: {
    //用户openid
    user_openid: '',
    //用户信息
    userInfo: null
  },
  
    onLaunch() {
      wx.cloud.init({
        //云开发环境id
        env: 'asd123-0g56ch1xd890d217' ,
        traceUser: true,
      })
    }
      //调用云函数
    //全局数据
  })

  
  