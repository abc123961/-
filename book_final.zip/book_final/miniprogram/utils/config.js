module.exports={
  
  baseUrl:"https://api.zhuishushenqi.com",
  baseImgUrl:"https://statics.zhuishushenqi.com",
    contactUrl:"https://chapter2.zhuishushenqi.com"
}