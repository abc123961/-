module.exports={
  
    READ_BOOK_KEY:"bookRead",
    READER_INFO_KEY:"readerInfo",
}