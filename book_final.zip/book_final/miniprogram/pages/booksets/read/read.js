const db = wx.cloud.database();
const app = getApp();

Page({
  data: {
    bookId: '',
    currentChapter: {},
    chapters: [],
    isFirstChapter: false,
    isLastChapter: false,
    fontSize: 28, // 默认字体大小
    fontColor: '#000000', // 默认字体颜色
    isDarkMode: false, // 默认不启用深色模式
    isEyeCareMode: false // 默认不启用护眼模式
  },

  onLoad: function (options) {
    this.setData({
      bookId: options.id
    });
    this.loadChapters(options.id, options.chapter);
  },
  scrollToTop: function() {
    wx.pageScrollTo({
      scrollTop: 0, // 滚动到页面顶部
      duration: 300  // 滚动动画时间（毫秒）
    });
  },

  loadChapters: function (id, chapterIndex) {
    db.collection('chapter').where({
      Book: this.data.bookId
    }).orderBy('index', 'asc').get().then(res => {
      if (res.data.length > 0) {
        this.setData({
          chapters: res.data
        });
        this.loadCurrentChapter(chapterIndex);
      } else {
        wx.showToast({
          title: '暂无章节信息'
        });
      }
    }).catch(err => {
      console.error('查询章节时发生错误：', err);
      wx.showToast({
        title: '查询章节失败'
      });
    });
  },

  loadCurrentChapter: function(chapterIndex) {
    const chapters = this.data.chapters;
    if (chapters.length === 0) {
      wx.showToast({
        title: '章节信息未加载'
      });
      return;
    }
    const currentChapter = chapters.find(chapter => chapter.index == chapterIndex);
    if (currentChapter) {
      const cleanedContent = currentChapter.content.replace(/<p>/g, '\n').replace(/<\/p>/g, '');
      this.setData({
        currentChapter: {
          ...currentChapter,
          content: cleanedContent // 将清理后的内容赋值
        },
        isFirstChapter: chapterIndex === 1,
        isLastChapter: chapterIndex === chapters.length
      });
    } else {
      wx.showToast({
        title: '章节未找到'
      });
    }
  },

  changeFontSize: function(e) {
    const size = e.currentTarget.dataset.size;
    switch(size) {
      case 'small':
        this.setData({ fontSize: 20 });
        break;
      case 'medium':
        this.setData({ fontSize: 28 });
        break;
      case 'large':
        this.setData({ fontSize: 36 });
        break;
    }
  },

  changeFontColor: function(e) {
    const color = e.currentTarget.dataset.color;
    this.setData({ fontColor: color });
  },

  toggleDarkMode: function(e) {
    this.setData({ isDarkMode: e.detail.value });
  },

  toggleEyeCareMode: function(e) {
    this.setData({ isEyeCareMode: e.detail.value });
  },

  goToPrevious: function () {
    this.loadCurrentChapter(this.data.currentChapter.index - 1);
  },

  goToNext: function () {
    this.loadCurrentChapter(this.data.currentChapter.index + 1);
  },

  goToDirectory: function() {
    const id = this.data.bookId;
    console.log(id);
    wx.navigateTo({
       url:`/pages/booksets/detail/detail?id=${id}`
    });
  }
});
