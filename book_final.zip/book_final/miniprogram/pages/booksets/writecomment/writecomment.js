const db = wx.cloud.database();
const app = getApp();

Page({
  data: {
    book_id: '',
    score: 0,
    selectedRating: null,
    comment: ''
  },

  onLoad(options) {
    this.setData({ book_id: options.id });
  },

   // 选择评分
   chooseRating(event) {
    const rating = event.currentTarget.dataset.rating;
    this.setData({
      selectedRating: rating
    });
  },

  // 输入评论
  inputComment(event) {
    this.setData({
      comment: event.detail.value
    });
  },

  // 提交评论
  submitComment() {
    if (!this.data.selectedRating || !this.data.comment) {
      wx.showToast({
        title: '请先填写评分和评论',
        icon: 'none'
      });
      return;
    }
    // 提交评论的逻辑
    console.log('提交评分:', this.data.selectedRating, '提交评论:', this.data.comment);
  },

  checkIfUserHasCommented: async function(book_id, user_id) {
    try {
      const res = await db.collection('comments').where({
        book_id: book_id,
        user_id: user_id
      }).get();

      return res.data.length > 0;
    } catch (err) {
      console.error('查询评论时发生错误：', err);
      return false;
    }
  },

  updateBookScore: async function(book_id) {
    try {
      const res = await db.collection('comments').where({
        book_id: book_id
      }).get();

      const comments = res.data;
      if (comments.length === 0) {
        return;
      }

      const totalScore = comments.reduce((sum, comment) => sum + comment.score, 0);
      const averageScore = totalScore / comments.length;
      console.log(averageScore);

      const bookRes = await db.collection('book').doc(book_id).get();
      const bookDoc = bookRes.data;

      if (!bookDoc.score) {
        console.log("不存在");
        // 如果不存在，先添加 score 字段
        await db.collection('book').doc(book_id).update({
          data: {
            score: 0 // 初始化为0或其他默认值
          }
        });
      }
      await db.collection('book').doc(book_id).update({
        data: {
          score: averageScore
        }
      });

      console.log('书籍评分更新成功');
    } catch (err) {
      console.error('更新书籍评分时发生错误：', err);
    }
  },

  submitComment: async function() {
    const { book_id, selectedRating, comment } = this.data; // 注意使用 selectedRating 而非 score
    const user_id = app.globalData.user_openid; // 假设用户 openid 存储在全局数据中
  
    if (!selectedRating || !comment) { // 检查 selectedRating 而非 score
      wx.showToast({
        title: '评分和评论内容不能为空',
        icon: 'none'
      });
      return;
    }
  
    const hasCommented = await this.checkIfUserHasCommented(book_id, user_id);
  
    if (hasCommented) {
      wx.showToast({
        title: '您已评论过该书籍',
        icon: 'none'
      });
      return;
    }
  
    db.collection('comments').add({
      data: {
        book_id,
        user_id,
        score: selectedRating, // 保存评分时使用 selectedRating
        comment,
        time: new Date().toISOString()
      }
    }).then(async () => {
      wx.showToast({
        title: '评论成功',
        icon: 'success'
      });
  
      // 更新书籍评分
      await this.updateBookScore(book_id);
  
      wx.navigateBack();
    }).catch(err => {
      console.error('评论失败：', err);
      wx.showToast({
        title: '评论失败',
        icon: 'none'
      });
    });
  }
  
});