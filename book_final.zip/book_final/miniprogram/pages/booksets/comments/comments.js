const db = wx.cloud.database();
const app = getApp();

Page({
  data: {
    bookId: '',
    comments: []
  },

  onLoad(options) {
    this.setData({ bookId: options.id });
    this.loadComments();
  },
  onShow(options) {
    //this.setData({ bookId: options.id });
    this.loadComments();
  },
  loadComments: async function() {
    try {
      const bookId = this.data.bookId;
      const res = await db.collection('comments').where({
        book_id: bookId
      }).get();

      const comments = res.data;
      const userIds = comments.map(comment => comment.user_id);

      // 创建一个 Promise 数组，用于存储所有用户信息查询的 Promise
      const userInfoPromises = userIds.map(userId => {
        return getUserInfo(userId);
      });

      // 使用 Promise.all 等待所有用户信息查询完成
      const userInfos = await Promise.all(userInfoPromises);

      // 将用户信息与评论数据合并
      const enrichedComments = comments.map((comment, index) => {
        const userInfo = userInfos[index];
        console.log(userInfo.avatar);
        console.log(userInfo.nickName);
        return {
          ...comment,
          avatar: userInfo.avatarUrl,
          nickname: userInfo.nickName,
          formattedTime: formatTime(comment.timestamp),
          score: comment.score || 0 // 如果评论中有评分字段，可以在这里处理
        };
      });

      // 设置页面的评论数据
      this.setData({
        comments: enrichedComments
      });
    } catch (err) {
      console.error('查询评论或用户信息时发生错误：', err);
    }
  },

  goToWriteComment: function() {
    wx.navigateTo({
      url: `/pages/booksets/writecomment/writecomment?id=${this.data.bookId}`
    });
  },
  deleteComment: function() {
    const user_id = app.globalData.user_openid;
    const book = this.data.bookId; // 假设 book_id 存储在页面数据中
    console.log("user_id"+user_id);
    console.log(book);
    db.collection('comments').where({
      user_id: user_id,
      book_id: book
    })
    .get({
      success: function(res) {
        // res.data 是包含以上定义的两条记录的数组
        console.log("DA"+res.data)
      }
    })
    db.collection('comments').where({
      user_id: user_id,
      book_id: book
    }).remove().then(res => {
      console.log(res); // 添加调试信息
      if (res.stats.removed > 0) {
        wx.showToast({
          title: '删除评论成功',
          icon: 'success'
        });
        this.onShow();
      } else {
        wx.showToast({
          title: '没有找到可删除的评论',
          icon: 'none'
        });
      }
    }).catch(err => {
      console.error('删除评论时发生错误：', err);
      wx.showToast({
        title: '删除评论失败',
        icon: 'none'
      });
    });
  }
})
  
// 定义 getUserInfo 函数
async function getUserInfo(user_id) {
  try {
    const res = await db.collection('userInfo').where({
      _openid: app.globalData.user_openid
    }).get();

    if (res.data.length > 0) {
      return res.data[0];
    } else {
      throw new Error(`用户 ${user_id} 不存在`);
    }
  } catch (err) {
    console.error('查询用户信息时发生错误：', err);
    throw err;
  }
}

// 定义 formatTime 函数
function formatTime(timestamp) {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hour = date.getHours();
  const minute = date.getMinutes();
  return `${year}-${padZero(month)}-${padZero(day)} ${padZero(hour)}:${padZero(minute)}`;
}

// 辅助函数，用于补零
function padZero(num) {
  return num < 10 ? `0${num}` : num;
}