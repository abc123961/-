const db = wx.cloud.database();
const app =getApp();
Page({
  data: {
    book: {},
    chapters: [],
    flag: ''
  },
  
  onLoad(options) {
    const id = options.id;
    this.loadBookDetail(id);
    this.loadBookDetails(id);
  },

  loadBookDetails: function(id) {
    // 调用云函数或其他方法获取书籍详情和章节
  //  console.log(id);
    db.collection('chapter').where({
      Book: id
    }).orderBy('index', 'asc').get().then(res => {
      if (res.data.length > 0) {
        this.setData({
          chapters: res.data
        });
      } else {
        wx.showToast({
          title: '暂无章节信息',
          icon: 'none'
        });
      }
    }).catch(err => {
      console.error('查询章节时发生错误：', err);
      wx.showToast({
        title: '查询章节失败',
        icon: 'none'
      });
    });
  },
  loadBookDetail(id) {
    db.collection('book').doc(id).get().then(res => {
      this.setData({
        book: res.data
      });
      // 确保 book 数据已经设置后再查询 bookshelf
      db.collection('bookshelf').where({
        reader_id: app.globalData.user_openid,
        book_id: res.data._id
      }).get({
        success: res => {
          const flag = res.data.length > 0 ? '1' : '0';
          this.setData({
            flag: flag
          });
          //console.log('Flag set to:', this.data.flag); // 确保 flag 已经被正确赋值
        },
        fail: err => {
          console.error('查询书架时发生错误：', err);
        }
      });
    }).catch(err => {
      console.error('查询书籍时发生错误：', err);
    });
  },

  startReading: function() {
    console.log(this.data.book._id);
    wx.navigateTo({
      url: `/pages/booksets/read/read?id=${this.data.book._id}&chapter=1`
    });
  },
  toggleFavorite: function() {
    const { flag, book } = this.data;
    const reader = app.globalData.user_openid;

    if (flag === '0') {
      // 收藏书籍
      db.collection('bookshelf').add({
        data: {
          reader_id: reader,
          book_id: this.data.book._id,
        }
      }).then(res => {
        wx.showToast({
          title: '收藏成功',
          icon: 'success'
        });
        this.setData({
          flag: '1'
        });
      }).catch(err => {
        console.error('收藏书籍时发生错误：', err);
        wx.showToast({
          title: '收藏失败',
          icon: 'none'
        });
      });
    } else if (flag === '1') {
      // 取消收藏书籍
      const reader=app.globalData.user_openid;
      console.log(reader);
      console.log(book._id);
      db.collection('bookshelf').where({
        reader_id: reader,
        book_id: this.data.book._id
      }).remove().then(res => {
        console.log(res); // 添加调试信息
        if (res.stats.removed > 0) {
          wx.showToast({
            title: '取消收藏成功',
            icon: 'success'
          });
          this.setData({
            flag: '0'
          });
        } else {
          wx.showToast({
            title: '取消收藏失败，未找到匹配记录',
            icon: 'none'
          });
        }
      }).catch(err => {
        console.error('取消收藏时发生错误：', err);
        wx.showToast({
          title: '取消收藏失败',
          icon: 'none'
        });
      });
    }
  },
  goToComments: function() {
    wx.navigateTo({
      url: `/pages/booksets/comments/comments?id=${this.data.book._id}`
    });
  }
  
});