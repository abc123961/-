const db = wx.cloud.database();

Page({
  data: {
    books: []
  },
  
  onLoad(options) {
    this.loadBooks(options.category);
  },
  
  loadBooks(label) {
    db.collection('book').where({
      label:label
    }).orderBy('score', 'desc').get().then(res => {
      this.setData({
        books: res.data
      });
    });
  },

  navigateToDetail(event) {
    const id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/booksets/detail/detail?id=${id}`
    });
  },

  toggleFavorite(event) {
    const id = event.currentTarget.dataset.id;
    wx.showToast({
      title: '收藏功能待实现',
      icon: 'none'
    });
  }
});
