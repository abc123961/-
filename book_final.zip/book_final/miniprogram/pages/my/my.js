const app = getApp();

Page({
  data: {
      userInfo: null
    },
    logout(){
        app.globalData.userInfo=null;
        app.globalData.user_openid='';
        this.setData({
            userInfo:null,
            user_openid:''
        })
    },
    login() {
      wx.cloud.callFunction({
        name: 'get_openid',
        success: res => {
          //获取用户openid
          app.globalData.user_openid = res.result.userInfo.openId
        }
      })
      console.log(app.globalData.userInfo);
      console.log(app.globalData.user_openid);
      //let that = this;
      wx.getUserProfile({
        desc: '获取用户信息',
        success: res => {
          console.log(res.userInfo)
          var user = res.userInfo
          //设置全局用户信息
          app.globalData.userInfo = user
          //设置局部用户信息
          this.setData({
            userInfo: user
          })
          const db = wx.cloud.database({
            env: 'asd123-0g56ch1xd890d217'
          })
          //检查之前是否已经授权登录
          db.collection('userInfo').where({
            _openid: app.globalData.user_openid
          }).get({
            success: res => {
              //原先没有添加，这里添加
              if (!res.data[0]) {
                //将数据添加到数据库
                wx.cloud.database().collection('userInfo').add({
                  data: {
                    avatarUrl: user.avatarUrl,
                    nickName: user.nickName
                  },
                  success: res => {
                    wx.showToast({
                      title: '登录成功',
                      icon: 'none'
                    })
                  }
                })
              } else {
                //已经添加过了
                this.setData({
                  userInfo: res.data[0]
                })
              }
            }
          })
        }
      })
      console.log(app.globalData.userInfo);
      console.log(app.globalData.user_openid);
    },  
  /*
    onLoad: function (options) {
      this.setData({
        userInfo: app.globalData.userInfo
      })
    },*/
  })