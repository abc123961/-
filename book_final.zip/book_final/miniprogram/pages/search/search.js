// pages/yourPageName/yourPageName.js  
const db=wx.cloud.database();

Page({  
  data: {  
    seainfo: "",
    books:[]
  },  
  
  onSeainfo(e) {  
    this.setData({  
      seainfo: e.detail.value // 更新seainfo数据  
    });  
    console.log("input:"+e.detail.value);
    let seainfo=e.detail.value;
    db.collection('book').where(db.command.or([
      {
        name:db.RegExp({
          regexp:seainfo,
          options:'i'
        })
      },
      {
        intro:db.RegExp({
          regexp:seainfo,
          options:'i'
        })
      },
      {
        author:db.RegExp({
          regexp:seainfo,
          options:'i'
        })
      },
      {
        label:db.RegExp({
          regexp:seainfo,
          options:'i'
        })
      }
    ])).get().then(res=>{
      console.log(res.data);
      this.setData({
        books:res.data
      })
    })
  },
  navigateToDetail(event) {
    const id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/booksets/detail/detail?id=${id}`
    });
  }
  
});