const db=wx.cloud.database();
const app=getApp();

Page({
  /**
   * 页面的初始数据
   */
  data: {
    list: [], // 改为数组
    word: '',
    message: '',
    //用户openid
    user_openid: '',
    //用户信息
    userInfo: null,
    books:[],
    len:0
  },

  onShow(options) {  
    // 从全局数据中获取 user_openid 和 userInfo  
    let user_openid = app.globalData.user_openid;  
    let userInfo = app.globalData.userInfo;  
    
    // 设置页面的初始数据  
    this.setData({  
      user_openid: user_openid,  
      userInfo: userInfo  
    });  
    
    console.log("!!!" + this.data.user_openid + this.data.userInfo);  
    
    // 从数据库获取书架上的书籍信息  
    db.collection('bookshelf').where({  
      reader_id: user_openid,  
    }).get({  
      success: (res) => {  
        console.log(res.data);  
        let books = res.data; // 这里直接使用 res.data，不需要额外的变量赋值  
        console.log(books);  
    
        if (books.length > 0) {  
          console.log("id: " + books[0].reader_id);  
    
          // 创建一个 Promise 数组，用于存储所有书籍查询的 Promise  
          let bookPromises = books.map(book => {  
            return db.collection('book').where({  
              _id: book.book_id  
            }).get();  
          });  
    
          // 使用 Promise.all 等待所有书籍查询完成  
          Promise.all(bookPromises).then(results => {  
            // 将所有查询结果合并到一个数组中  
            let books1 = results.map(result => result.data).flat(); // 假设每个查询只返回一个文档，使用 flat() 将二维数组展平  
    
            // 设置页面的书籍数据  
            this.setData({  
              books: books1  ,
              len:books1.length
            });  
    
            console.log("所有书籍数据已设置到页面：", books);  
            console.log(this.data.books[0].name);
          }).catch(error => {  
            console.error("查询书籍时发生错误：", error);  
          });  
        } else {  
          console.log('数组 books 为空');  
          // 如果书架为空，可以设置一个空数组到页面数据  
          this.setData({  
            books: []  ,
            len:0
          });  
        }  
      },  
      fail: (error) => {  
        console.error("查询书架时发生错误：", error);  
      }  
    });  
  },
  navigateToDetail(event) {
    const id = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/booksets/detail/detail?id=${id}`
    });
  }
  
});
