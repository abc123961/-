const db=wx.cloud.database();
const app=getApp();
Page({
  data: {
    books: []
  },

  onLoad: function(options) {
    // 页面加载时可以调用加载书籍的方法
    this.loadBooks();
  },

  loadBooks: function() {
    db.collection('book').get().then(res => {
      this.setData({
        books: res.data
      });
    }).catch(err => {
      console.error('加载书籍失败：', err);
    });
  },

  addBook: function() {
    const newBookData = {
      author: "姜文",
      book_id: "9", // 替换为您的书本编号
      chapter_sum: 5,
      cover: "cloud://cloudid.607890d217.6173-asd123-og56ch1xd890d", // 替换为您的封面图片 URL
      createBy: "18450708844210001217",
      createdAt: Date.now(),
      intro: "《三国演义》（又名《三国志演义》《三国志通俗演义》，是元末明初小说家罗贯中根据陈寿《三国志》和裴松之注解以及民间三…", // 替换为您的书籍简介
      label: "现代",
      name: "让子弹飞",
      owner: "18450708844210001217",
      score: 10,
      updateBy: "18450708844210001217"
    };

    db.collection('book').add({
      data: newBookData
    }).then(res => {
      console.log('新记录的 _id:', res._id);
      // 刷新书籍列表
      this.loadBooks();
    }).catch(err => {
      console.error('添加书籍记录失败:', err);
    });
  }
});